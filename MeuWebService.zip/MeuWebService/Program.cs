using Microsoft.AspNetCore.Authentication.JwtBearer;

using Microsoft.AspNetCore.Authorization;

using Microsoft.AspNetCore.Mvc;

using Microsoft.EntityFrameworkCore;

using Microsoft.IdentityModel.Tokens;

using Microsoft.OpenApi.Models;

using System;

using System.Collections.Generic;

using System.IdentityModel.Tokens.Jwt;

using System.Security.Claims;

using System.Text;

var builder = WebApplication.CreateBuilder(args);

// Configura��o da base de dados SQL Server

builder.Services.AddDbContext<AppDbContext>(options =>

    options.UseSqlServer(builder.Configuration.GetConnectionString("DefaultConnection")));

// Configura��o da autentica��o JWT

/*var key = Encoding.ASCII.GetBytes(builder.Configuration["JwtSettings:SecretKey"]);

if (key.Length < 128)

{

    throw new ArgumentException("A chave secreta deve ter pelo menos 128 bits.");

}*/

var secretKey = builder.Configuration["JwtSettings:SecretKey"];

if (string.IsNullOrEmpty(secretKey))

{

    throw new ArgumentException("A chave secreta n�o pode ser nula ou vazia.");

}

var key = Encoding.ASCII.GetBytes(secretKey);


builder.Services.AddAuthentication(options =>

{

    options.DefaultAuthenticateScheme = JwtBearerDefaults.AuthenticationScheme;

    options.DefaultChallengeScheme = JwtBearerDefaults.AuthenticationScheme;

})

.AddJwtBearer(options =>

{

    options.RequireHttpsMetadata = false;

    options.SaveToken = true;

    options.TokenValidationParameters = new TokenValidationParameters

    {

        ValidateIssuerSigningKey = true,

        IssuerSigningKey = new SymmetricSecurityKey(key),

        ValidateIssuer = false,

        ValidateAudience = false

    };

});

// Configura��o do Swagger com suporte para autentica��o

builder.Services.AddEndpointsApiExplorer();

/*builder.Services.AddSwaggerGen(c =>

{

    c.SwaggerDoc("v1", new OpenApiInfo { Title = "MeuWebService", Version = "v1" });

    var securityScheme = new OpenApiSecurityScheme

    {

        Name = "Authorization",

        Description = "Entre com o token JWT",

        In = ParameterLocation.Header,

        Type = SecuritySchemeType.Http,

        Scheme = "bearer",

        BearerFormat = "JWT",

        Reference = new OpenApiReference

        {

            Type = ReferenceType.SecurityScheme,

            Id = "Bearer"

        }

    };

    c.AddSecurityDefinition("Bearer", securityScheme);

    c.AddSecurityRequirement(new OpenApiSecurityRequirement

    {

        { securityScheme, new string[] {} }

    });

});

*/

builder.Services.AddSwaggerGen(c =>

{

    c.SwaggerDoc("v1", new OpenApiInfo { Title = "MeuWebService", Version = "v1" });

    var securityScheme = new OpenApiSecurityScheme

    {

        Name = "Authorization",

        Description = "Entre com o token JWT",

        In = ParameterLocation.Header,

        Type = SecuritySchemeType.Http,

        Scheme = "bearer",

        BearerFormat = "JWT",

        Reference = new OpenApiReference

        {

            Type = ReferenceType.SecurityScheme,

            Id = "Bearer"

        }

    };

    c.AddSecurityDefinition("Bearer", securityScheme);

    // Requisita o token de autentica��o para todas as opera��es

    c.AddSecurityRequirement(new OpenApiSecurityRequirement

    {

        { securityScheme, new string[] { } }

    });

});

builder.Services.AddControllers();

/** novo codigo fim **/


var app = builder.Build();

// Configure the HTTP request pipeline.

if (app.Environment.IsDevelopment())

{

    app.UseSwagger(); // novo

    app.UseSwaggerUI(); // novo

}

// app.UseHttpsRedirection(); // nao necess�rio !!!!

app.UseAuthentication();

app.UseAuthorization();

app.MapControllers();

app.Run();

// Classe de contexto da base de dados

public class AppDbContext : DbContext

{

    public AppDbContext(DbContextOptions<AppDbContext> options) : base(options) { }

    public DbSet<Produto> Produtos { get; set; }

    protected override void OnModelCreating(ModelBuilder modelBuilder)

    {

        modelBuilder.Entity<Produto>().ToTable("Produto");

    }

}

// Modelo de dados de Produto

public class Produto

{

    public int Id { get; set; }

    public string Titulo { get; set; }

    public int Preco { get; set; }

    public bool Ativo { get; set; }

}

// Controlador com opera��es CRUD

[Authorize]

[ApiController]

[Route("api/[controller]")]

public class ProdutosController : ControllerBase

{

    private readonly AppDbContext _context;

    public ProdutosController(AppDbContext context)

    {

        _context = context;

    }

    [HttpGet]

    public async Task<ActionResult<IEnumerable<Produto>>> GetProdutos()

    {

        return await _context.Produtos.ToListAsync();

    }

    [HttpGet("{id}")]

    public async Task<ActionResult<Produto>> GetProduto(int id)

    {

        var produto = await _context.Produtos.FindAsync(id);

        if (produto == null) return NotFound();

        return produto;

    }

    [HttpPost]

    public async Task<ActionResult<Produto>> CreateProduto(Produto produto)

    {

        _context.Produtos.Add(produto);

        await _context.SaveChangesAsync();

        return CreatedAtAction(nameof(GetProduto), new { id = produto.Id }, produto);

    }

    [HttpPut("{id}")]

    public async Task<IActionResult> UpdateProduto(int id, Produto produto)

    {

        if (id != produto.Id) return BadRequest();

        _context.Entry(produto).State = EntityState.Modified;

        await _context.SaveChangesAsync();

        return NoContent();

    }

    [HttpDelete("{id}")]

    public async Task<IActionResult> DeleteProduto(int id)

    {

        var produto = await _context.Produtos.FindAsync(id);

        if (produto == null) return NotFound();

        _context.Produtos.Remove(produto);

        await _context.SaveChangesAsync();

        return NoContent();

    }

}
// Modelo de dados de User

public class LoginModel

{

    public string Username { get; set; }

    public string Password { get; set; }

    public int Type { get; set; }

}


[ApiController]

[Route("api/[controller]")]

public class AuthController : ControllerBase

{

    private readonly IConfiguration _configuration;

    public AuthController(IConfiguration configuration)

    {

        _configuration = configuration;

    }

    [HttpPost("login")]

    public IActionResult Login([FromBody] LoginModel login)

    {

        // Valide o utilizador, por exemplo, com base de dados

        if (login.Username == "admin" && login.Password == "senha" && login.Type == 1) // Valida��o fict�cia

        {

            var claims = new[]

            {

                new Claim(ClaimTypes.Name, login.Username),

                new Claim(ClaimTypes.Role, "Admin"),

            };

            var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_configuration["JwtSettings:SecretKey"]));

            var creds = new SigningCredentials(key, SecurityAlgorithms.HmacSha256);

            var token = new JwtSecurityToken(

                issuer: "myissuer",

                audience: "myaudience",

                claims: claims,

                expires: DateTime.Now.AddMinutes(30),

                signingCredentials: creds

            );

            return Ok(new

            {

                token = new JwtSecurityTokenHandler().WriteToken(token)

            });

        }

        return Unauthorized();

    }

}